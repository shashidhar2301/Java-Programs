package com.collections;

public class Parent {

}
