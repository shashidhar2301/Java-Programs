package com.collections;

public class TestParentClass {

		public static void main(String[] args) {
			
			
			//TestParentClass t = new TestParentClass();
			
			//Parent p = new Parent();
			//Child c = new Child();
			callMethod(new Parent());
			callMethod(new Child());
			
			
			//String s1 = "abc";
			callMethod("abd");
			
		}
		
		
		static void callMethod(Parent p){
			System.out.println("callllll");
			
		}
		static void callMethod(String s){
			
			
			}
}

