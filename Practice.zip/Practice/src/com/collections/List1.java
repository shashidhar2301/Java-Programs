package com.collections;

import java.awt.List;
import java.util.ArrayList;

public class List1 {

	public static void main(String[] args) {

		ArrayList<String> li = new ArrayList<>();
		li.add("java");
		li.add("c");
		li.add("c+");
		li.add("java");
		System.out.println(li.indexOf("java"));
	}

}
