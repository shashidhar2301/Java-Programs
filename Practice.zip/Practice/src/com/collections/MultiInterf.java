package com.collections;

public class MultiInterf implements  Inter1,Inter2{
 
	public static void main(String[] args) {
		
		Inter2 m = new MultiInterf();
		m.add(1, 2);
		
		Inter1 m1 = new MultiInterf();
		m1.add(1, 2);
		 
		
	}

	@Override
	public int add(int a, int b) {
		// TODO Auto-generated method stub
		return 0;
	}

	 

}


