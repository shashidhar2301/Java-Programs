package com.collections;

import java.util.HashMap;
import java.util.Set;

public class HashMap1 {

	 public static void main(String[] args) {
		
		 HashMap<String, Integer> hm = new HashMap<>();
		 
		 
		 hm.put("abc",1);
		 hm.put("xyz",2);
		 
		 Set s =hm.entrySet();
		 s.iterator();
		 
		 hm.values().stream().forEach(x->System.out:println));
		 
	}
	
	
}
