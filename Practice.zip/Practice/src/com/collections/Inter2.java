package com.collections;

public interface Inter2 {
	public int add(int a,int b);
	
	default void m() {
		System.out.println("huuuhkj");
	}
}
