package com.collections;

public interface Inter1 {

	public int add(int a,int b);
}
