package com.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HighestInArray {

		public static void main(String[] args) {
			
			List<String> li = new ArrayList<>();
			List<String> newLi = new ArrayList<>();
			
			li.add("0");
			li.add("0");
			li.add("0");
			li.add("0");
			li.add("0");
			li.add("2000");
			li.add("2000");
			li.add("0");
			li.add("3000");
			li.add("2000");
			li.add("2000");
			li.add("0");
			//li.add("3000");
			li.add("0");
			li.add("0");
			li.add("0");
			newLi.addAll(li);
			System.out.println(li);
			System.out.println(newLi);
			Collections.sort(li);
			System.out.println(li);
			System.out.println(newLi.lastIndexOf(li.get(li.size()-1)));
			
		}
}
