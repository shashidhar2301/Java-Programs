package com.collections;

public class Child extends Parent {
	
	

}
