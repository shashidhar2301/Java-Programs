package com.Exceptions;

public class CallingCustomEx {

	public static void main(String[] args) throws CustomExClass {
		
		
		try {
			
			throw new CustomExClass("Hello");
			
		}catch(CustomExClass e) {
			System.out.println("main class ex::"+e.getMessage());
			throw new CustomExClass("beyy");
		}catch(Exception e) {
			System.out.println("main class ex"+e.getMessage());
		}
	}
}
