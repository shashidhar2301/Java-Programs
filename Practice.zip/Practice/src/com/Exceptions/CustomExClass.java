package com.Exceptions;

public class CustomExClass extends Exception{
	
	 CustomExClass(){
		System.out.println("Exception class constructor");
	}
	public CustomExClass(String str){
		super(str);
		System.out.println("Exception class constructor2:"+str);
	}

}
