package com.Exceptions;

public class ChildException extends SuperException{

	void add()   {
		System.out.println("child method");
		String str = null;
		  str.charAt(0);
	}
	
	public static void main(String[] args) throws  Exception    {
		
		ChildException ch = new ChildException();
		ch.add();
		
	}
}
