package com.Exceptions;

public class TryReturn {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("main before method call");
		returingMethod(5);
		System.out.println("main after method call");
	}
	
	static int returingMethod(int i) throws ArithmeticException{
		
		i = i/0;
		/*try {
			
			for(i=0;i<10;i++) {
				System.out.println("in try "+i);
				i = i/0;
					//return i;
				System.out.println("in try after returning "+i);
			}
			System.out.println("after return");
		}catch(Exception e){
			System.out.println("catch");
			return i;
		}finally {
			System.out.println("in final");
		}*/
		return i;
		
	}

}
