package com.Exceptions;

public class SuperException {

	
	
	void add()  throws  Exception {
		System.out.println("parent method");
		try {
			  
			}catch(Exception e) {
				System.out.println("parent method"+e.getMessage());
			}
	}

}
