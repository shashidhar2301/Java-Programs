package com.demo;

public class Grand extends Test{

	protected int grandID;
	 protected static String grandName="G";
	 
	 public Grand(){
		this.grandID++;
		Grand.childName+=Test.childName+Demo.parentName;
	 }
	 public void display(){
		 super.display();
			System.out.println(this.grandID+""+Grand.childName);
		 }
	 public static void main(String[] args) {
			Demo c = new Grand();
			c.display();
			
			
		}
}

