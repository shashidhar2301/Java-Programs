package com.demo;

public class Test extends Demo{
	
	
	protected int childID;
	 protected static String childName="C";
	 
	 public Test( ){
		this.childID++;
		Test.childName= Test.childName+ Demo.parentName;
	 }
	 public void display(){
		 super.display();
			System.out.println(this.childID+""+Test.childName);
		 }
}


