package com.demo;

public class Demo {
	
	
	protected int parentID=0;
	 protected static String parentName="P";
	 
	 public Demo(){
		this.parentID++;
		Demo.parentName+='P';
	 }
	 protected void display(){
			System.out.println(this.parentID+""+Demo.parentName);
		 }
}
