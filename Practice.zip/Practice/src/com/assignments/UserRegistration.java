package com.assignments;

import java.util.Scanner;

public class UserRegistration {

	
	public static void main(String[] args) {
		
		UserRegistration ur = new UserRegistration();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter User Name  : ");
		
		String name = sc.nextLine();
		
		System.out.println("Enter User Country  : ");
		
		String country = sc.nextLine();
		try {
			ur.registerUser(name, country);
		} catch (InvalidCountryException e) {
			e.printStackTrace();
		}
		 
	}
 
	void registerUser(String userName, String userCountry) throws InvalidCountryException {
		
		if(userCountry!=null && !"India".equalsIgnoreCase(userCountry)) {
			throw new InvalidCountryException("User outside India cannot be registered");
		}else
			System.out.println("User registeration done succesfully");
		
	}
}



class InvalidCountryException extends Exception{

	public InvalidCountryException(String string) {
		super(string);
	}
	
}

