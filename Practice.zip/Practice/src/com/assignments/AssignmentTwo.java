package com.assignments;

import java.util.Scanner;

public class AssignmentTwo {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter size of an array");
		int size = sc.nextInt();
		int[] arr = new int[size];
		
		System.out.println("Enter elements in to that array");
		
		
		for(int i=0;i<size;i++) {
			arr[i] = sc.nextInt();
		}
	 	System.out.println("Which index u want :");
	 	
	 	int index = sc.nextInt();
	 	try {
	 		System.out.println("element at "+index+" is : "+arr[index]);
	 	}catch(Exception e) {
	 		System.out.println(e.getClass());
	 	}
		
		
	}
}
