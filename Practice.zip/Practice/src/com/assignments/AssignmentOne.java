package com.assignments;

import java.util.Scanner;

public class AssignmentOne {
	public static void main(String[] args) {
		
		Scanner sc1 = new Scanner(System.in);
		
		System.out.println("Enter an integer");
		
		String str = sc1.nextLine();
		//int num =  sc1.nextInt();
		
		try {
			int i = Integer.parseInt(str);
			
			//String s = Integer.toString(num);
			
			System.out.println("squre::"+i*i);
		}catch(Exception e) {
			System.out.println("Number Format exception");
		}
		
	}

}
