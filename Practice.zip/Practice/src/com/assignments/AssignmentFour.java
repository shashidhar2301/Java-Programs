package com.assignments;

import java.util.Scanner;

public class AssignmentFour {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter size of an array");
		int size = sc.nextInt();
		int[] arr = new int[size];
		int sum = 0, avg =0;
		
		System.out.println("Enter elements in to that array");
		
	 	
	 	try {

			for(int i=0;i<size;i++) {
				arr[i] = sc.nextInt();
				sum = sum +arr[i];
			}
	 		avg = sum/size;
	 		System.out.println("sum is :"+sum+"::average is : "+avg);
	 	}catch(ArithmeticException e) {
	 		System.out.println(e.getClass());
	 	}catch(NumberFormatException e) {
	 		System.out.println(e.getClass());
	 	}
		
		
	}
}
