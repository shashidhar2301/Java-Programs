package com.assignments;

import java.util.Scanner;

public class AssignmentNine {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter first number : ");
		
		int a = sc.nextInt();
		
		System.out.println("Enter Second Number : ");
		int b  = sc.nextInt();
		
		int quotient = 0;
		try {	 
			quotient = a/b;
			 System.out.println("Quotient is :"+quotient);
		} catch(ArithmeticException e) {
			System.out.println("Divisor can't be a zero "+b);
		}finally {
			System.out.println("Inside finally block");
		}
	}
}
