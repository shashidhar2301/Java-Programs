package com.assignments;

import java.util.Scanner;

public class AssignmentEight {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Name  : ");
		
		String name = sc.nextLine();
		
		System.out.println("Enter age of : "+name);
		int age  = sc.nextInt();
		try {	 
			if(age<18 || age>60) {
				throw new AgeIsInvalid("Please enter a valid age");
			}else
				System.out.println("Age of "+name+" is : "+age);
			 
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

class AgeIsInvalid extends Exception{

	public AgeIsInvalid(String string) {
		super(string);
	}
	
}

