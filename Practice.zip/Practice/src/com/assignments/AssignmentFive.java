package com.assignments;

import java.util.Scanner;

public class AssignmentFive {

	
	public static void main(String[] args) throws ArithmeticException{
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter first element");
		
		int first = sc.nextInt();
		
		System.out.println("Enter Second element");
		
		int second = sc.nextInt();
		
		int divison = first/second;
		System.out.println("divison:::::"+divison);
		 
		
		
	}
}
