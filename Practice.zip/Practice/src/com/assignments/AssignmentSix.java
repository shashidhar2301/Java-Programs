package com.assignments;

import java.util.Scanner;

public class AssignmentSix {

	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Name of the first student : ");
		
		String firstStudent = sc.nextLine();
		
		System.out.println("Enter marks in three subjects for student : "+firstStudent);
		
		int marks1[] = new int[3];
		int sum1 = 0,sum2 = 0; 
		
		try {
		for(int i=0;i<3;i++) {
			marks1[i] = sc.nextInt();
			if(marks1[i]<0 || marks1[i]>100)  
				throw new NonPositiveNumber("Please enter marks from range 0-100 only");
			 else
				sum1 = sum1+marks1[i];
		}
		
		
		System.out.println("Enter Name of the Second student : ");
		
		String secondStudent = sc.next();
		System.out.println("Enter marks in three subjects for student : "+secondStudent);
		int marks2[] = new int[3];
		
		for(int i=0;i<3;i++) {
			marks2[i] = sc.nextInt();
			if(marks2[i]<0 || marks2[i]>100) {
				throw new NonPositiveNumber("Please enter elements from range 0-100 only");
			}else
				sum2 = sum2+marks2[i];
			}
		System.out.println("Average  marks of 2 students "+(sum1+sum2)/2);
		}catch(NumberFormatException e) {
			System.out.println("Please enter numeric value");
		}catch(NonPositiveNumber e) {
			System.out.println(e);
		}
	}
}
class NonPositiveNumber extends Exception{

	public NonPositiveNumber(String string) {
		super(string);
	}
	
}
