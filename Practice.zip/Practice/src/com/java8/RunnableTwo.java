package com.java8;

public class RunnableTwo {

	public static void main(String[] args) {
		 
		Runnable r =()->{
			for(int i=0;i<100;i++) {
				System.out.println("child");
			}
		};
		Thread th = new Thread(r);
		th.start();
		for(int i=0;i<100;i++) {
			System.out.println("main");
		}
	}

}
 
