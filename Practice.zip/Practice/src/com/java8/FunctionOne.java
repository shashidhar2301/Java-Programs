package com.java8;

import java.util.function.Function;

public class FunctionOne {
	
	public static void main(String[] args) {
		
		Function<String, String> f = a -> a.toUpperCase();
		System.out.println(f.apply("abg"));
	}

}
