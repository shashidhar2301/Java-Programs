package com.java8.stream;

public class Armstrong {
	
	public static void main(String[] args) {
		
		int i = 153, temp, sum = 0;
		int j = i;
		
		
		while(i>0) {
			
			temp = i%10;
			sum  = sum + (temp*temp*temp);//27+125+1
			i = i/10;
		}
		if(sum == j) {
			System.out.println("true");
		}else
			System.out.println("no");
		
		
		
	}

}
