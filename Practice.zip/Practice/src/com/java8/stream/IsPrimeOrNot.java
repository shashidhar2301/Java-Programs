package com.java8.stream;

public class IsPrimeOrNot {
	
	public static void main(String[] args) {
		
		int num=13, count=0, limit=100;
		
		
		for(int j=limit;j>=1;j--) {
			
			count=0;
		
		for(int i=1;i<=j/2;i++) {
			if(j%i==0) {
				count++;
			}
		}
		if(count==1)  {
			System.out.println("Prime numbers are::"+j);
		}
		/*else
			System.out.println("Not a prime");
		}*/
		
	}
	}

}
