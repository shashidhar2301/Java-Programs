package com.java8.stream;

public class Fibonacci {
	
	public static void main(String[] args) {
		
		//0,1,1,2,3,5,8,13
		
		int i=0,j=1, limit =10, temp;
		System.out.print(i+","+j);
		for(int k = 0;k<limit;k++) {
			temp = i + j;
			i = j;
			j = temp;
			System.out.print(","+temp);
			
		}
		/*
		 * while(limit>0) {
		 * 
		 * }
		 */
		
		
		
		
	}

}
