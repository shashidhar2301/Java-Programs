package com.java8.stream;

public class ReverseOfString {
	
	
	public static void main(String[] args) {
		
		String str = "shashidhar";
		char[] ch = str.toCharArray();
		
		String[] s = str.split("");
		
		for(int i=ch.length-1;i>=0;i--) {
			System.out.println(ch[i]);
		}
		
		for(int j=s.length-1;j>=0;j--) {
			System.out.println(s[j]);
		}
		
	}

}
