package com.java8.stream;

public class OccOfCharUsingStream {
	
	public static void main(String[] args) {
		
		String str = "Shashidhar";
		
		long l = str.chars().filter(c->c=='a').count();
		System.out.println(l);
		
	}

}
