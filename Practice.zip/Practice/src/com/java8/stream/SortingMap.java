package com.java8.stream;

import java.util.HashMap;
import java.util.Scanner;

public class SortingMap {
	
	public static void main(String[] args) {
		/*
		String str = "shashidhar";
		
		String[] s = str.split("");
		
		HashMap<String, Integer> hm = new HashMap<>();
		
		for(String ss : s){
			if(hm.get(ss)==null)
					hm.put(ss,1);
			else
				hm.put(ss,hm.get(ss)+1);
		}
		System.out.println(hm);
		*/
	
		Scanner sc = new Scanner(System.in);
		
		System.out.println("1 to continue");
		int i = sc.nextInt();
		if(i==1) {
			count();
		}
		
	}
	
	public  static int count(){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String");
		String str = sc.next();
		System.out.println("Enter Character");
		String ch = sc.next();
		
		String[] s = str.split("");
		
		HashMap<String, Integer> hm = new HashMap<>();
		
		for(String ss : s){
			if(hm.get(ss)==null)
					hm.put(ss,1);
			else
				hm.put(ss,hm.get(ss)+1);
		}
		return hm.get(ch);
	}

}
