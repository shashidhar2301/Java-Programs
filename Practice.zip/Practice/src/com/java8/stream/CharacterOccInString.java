package com.java8.stream;

import java.util.Arrays;
import java.util.function.Consumer;

public class CharacterOccInString {
	
	public static void main(String[] args) {
		
		String str = "shashidhar";
		char ch = 'z' ;

		long count = str.chars().filter(c-> c==ch).count();
		System.out.println(count);
		
		
	}

}
