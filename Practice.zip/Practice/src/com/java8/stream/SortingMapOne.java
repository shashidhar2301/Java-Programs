package com.java8.stream;

import java.util.HashMap;
import java.util.Map;

public class SortingMapOne {

	public static void main(String[] args) {
		String str = "shashidhar";

		String[] s = str.split("");

		HashMap<String, Integer> hm = new HashMap<>();

		for (String ss : s) {
			if (hm.get(ss) == null)
				hm.put(ss, 1);
			else
				hm.put(ss, hm.get(ss) + 1);
		}
		
		hm.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);;
	}
}
