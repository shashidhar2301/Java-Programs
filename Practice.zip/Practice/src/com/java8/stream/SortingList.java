package com.java8.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Spliterator;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class SortingList {

	public static void main(String[] args) {

		List<Integer> li = new ArrayList<>(Arrays.asList(10, 2, 2, 2, 9, 6, 6, 4, 5, 7, 3));

		// li.stream().filter(i->i%2==0).forEach(System.out::println);
		// li.stream().sorted().forEach(System.out::println);
		/*li.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
		
		 int[] arr = li.stream().mapToInt(Integer::intValue).toArray();
		
		int m = Collections.min(li);
		System.out.println(m);*/

		// List ll = Arrays.stream(arr).boxed().collect(Collectors.toList());

		// li.forEach(System.out::println);

		List ll = li.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		// List ll =li.stream().distinct().collect(Collectors.toList());
		System.out.println(li.get(0));

		// List ll = li.stream().map(i->i*2).collect(Collectors.toList());
		// li.stream().limit(5).forEach(System.out::println);

	}

}
