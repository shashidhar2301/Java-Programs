package com.java8;

public class Student {

	public int id;
	public String name;
	
	protected Student(int sid, String sname) {
		this.id= sid;
		this.name=sname;
		
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return id+""+name;
	}
}
