package com.java8.Collections;

import java.util.HashSet;
import java.util.Set;

public class MainClass {
	
	public static void main(String[] args) {
		
		
		Pet p = new Pet();
		p.setName("a1");
		
		Set<Pet> hashSet = new HashSet<>();
		hashSet.add(p);
		Person per = new Person();
		per.setPets(hashSet);
		
		
		Set<Pet> hashSet2  = per.getPets();
		
		System.out.println("first::"+hashSet2);
		
		Pet p2 = new Pet();
		p2.setName("b2");
		
		hashSet2.add(p2);
		
		per.setPets(hashSet2);
		
		System.out.println(per);
		
	}

}
