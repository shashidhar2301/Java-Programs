package com.java8.Collections;

import java.util.Set;

public class Person {

	private Set<Pet> pets;

	public Set<Pet> getPets() {
		return pets;
	}

	public void setPets(Set<Pet> pets) {
		this.pets = pets;
	}

	public Person(Set<Pet> pets) {
		super();
		this.pets = pets;
	}

	public Person() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Person [pets=" + pets + "]";
	}
	
	
}
