package com.java8.Collections;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

public class MaxValueInCustomClass {

	public static void main(String[] args) {

		List<Employee> list = new ArrayList<Employee>();

		Employee emp = new Employee(1, "Shashidhar", 1900);
		Employee emp1 = new Employee(2, "Shiva", 762000);
		Employee emp2 = new Employee(3, "Vishnu", 43556.65);
		list.add(emp);
		list.add(emp1);
		list.add(emp2);
		
		Employee e1  = list.stream().max(
				Comparator.comparing(Employee::getSalary)).get();
		
		//System.out.println(e1);
		Employee e2 = list.stream().max(Comparator.comparing(Employee::getSalary))
				.get();

		System.out.println(e2);
		
		Employee e = list.stream().max(Comparator.comparing(Employee::getSalary))
		.orElseThrow(()->new RuntimeException(""));

	}

}

class Employee {

	private int id;
	private String name;
	private double salary;

	private Set<Integer> s;
	
	
	
	public Set<Integer> getS() {
		return s;
	}

	public void setS(Set<Integer> s) {
		this.s = s;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Employee(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", s=" + s + "]";
	}
	

}
