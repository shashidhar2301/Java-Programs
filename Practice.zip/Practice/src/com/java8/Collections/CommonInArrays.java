package com.java8.Collections;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class CommonInArrays {

	public static void main(String[] args) {

		int[] arr = new int[] { 1,3,5 ,2, 3 ,1};
		int[] arr1 = new int[] { 3,74,3,1 };

		List li = Arrays.asList(arr).stream()
				.filter(num1 -> Arrays.asList(arr1).stream().anyMatch(num2 -> num2 == num1))
				.collect(Collectors.toList());
		System.out.println(li);

		List li1 = Arrays.stream(arr).filter
		(number -> Arrays.stream(arr1).anyMatch(num2 -> num2==number)).boxed().collect(Collectors.toList());
		System.out.println(li1);
		 
		
	}

}
