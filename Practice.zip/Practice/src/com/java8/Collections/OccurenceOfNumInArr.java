package com.java8.Collections;

import java.util.Arrays;
import java.util.HashMap;
import java.util.stream.Collectors;

public class OccurenceOfNumInArr {
	
	
	public static void main(String[] args) {
		
		
		//Occurrence of string
		String str[] = {"shiva","manu","uma","manu"};
		
		Arrays.stream(str).collect(Collectors.groupingBy(s->s))
		.forEach((a,b) -> System.out.println(a+":::"+b.size()));
		
		//Occurrence of integer
		int arr[] = {1,2,5,7,5,2};
		Arrays.stream(arr).boxed().collect(Collectors.groupingBy(s->s))
		.forEach((a,b) -> System.out.println(a+"::"+b.size()));
		
		HashMap<Integer, Long> collect = Arrays.stream(arr).boxed().
		collect(Collectors.groupingBy(s->s, HashMap::new,Collectors.counting()));
		System.out.println(collect);
		
		
		
		
		 
		
	}

}
