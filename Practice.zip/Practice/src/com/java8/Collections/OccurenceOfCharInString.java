package com.java8.Collections;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class OccurenceOfCharInString {
	
	public static void main(String[] args) {
		
		String str = "abcdaxyz";
		
		//till java 8
		HashMap<Character, Integer> map = new HashMap<Character, Integer>();
		
		for(int i=0;i<str.length()-1;i++) {
			
			if(map.containsKey(str.charAt(i))) {
				map.put(str.charAt(i), map.get(str.charAt(i))+1);
			}else
				map.put(str.charAt(i),1);
			
		}
		System.out.println("Java 7:::"+map);
		Set<Entry<Character,Integer>> set = map.entrySet();
		
		for(Entry e: set) {
			System.out.println(e.getKey()+"::"+e.getValue());
		}
		
		for(Map.Entry<Character,Integer> e: map.entrySet()) {
			System.out.println(e.getKey()+"::"+e.getValue());
		}
		
		//in Java 8
		//char s[] = str.toCharArray();

		Map<String, Long> result = Arrays.stream(str.split("")).map(String::toLowerCase).
				collect(Collectors.groupingBy(s -> s, LinkedHashMap::new, Collectors.counting()));  
		System.out.println(result);  
		
		String[] sarr = str.split("");
		Arrays.stream(sarr). 
		collect(Collectors.groupingBy(s->s, HashMap::new,Collectors.counting()));		
	}

}
