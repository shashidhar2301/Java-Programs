package com.java8.Collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DuplicatesOfInt {
	
	
	public static void main(String[] args) throws IllegalAccessException {
		
		int arr[] = new int[]{9,7,1,2,8,5,3,1,5};
		
		int i = Arrays.stream(arr).sorted().distinct().skip(2).boxed().findFirst()
		.orElseThrow(()-> new IllegalAccessException());
		//.forEach(System.out::println);
		System.out.println(i);
		
		int max= Arrays.stream(arr).max().orElse(0);
		System.out.println(max);
		
		List<Integer> li = new ArrayList<Integer>();
		li.add(1);
		li.add(3);
		Integer[] arr1 = li.toArray(new Integer[0]);
		System.out.println(arr1.toString());
		Arrays.asList(arr1).stream().forEach(System.out::println);
		
	}

}
