package com.java8.Collections;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CollectorsJoining {
	
	public static void main(String[] args) {
		
		char[] ch = {'a','d','f','a'};
		
		String joinStr = Stream.of(ch)
		.map(str->new String(str))
		.collect(Collectors.joining());
		System.out.println("::"+joinStr);
		
		 
		
		
		
	}

}
