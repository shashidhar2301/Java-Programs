package com.java8;

import com.java8.Interfaces.FunInterf1;

public class LamdaOne {
	public static void main(String[] args) {
		//Type inference as we are not providing (int a,int b)
		FunInterf1 in = (x,y)->System.out.println("sum::"+(x+y));
		in.add(10, 0);
		
		FunInterf1 in1 = (x,y)->System.out.println("sum::"+(x+y));
		in1.add(10, 76);
	}
 
}
