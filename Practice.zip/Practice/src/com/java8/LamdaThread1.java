package com.java8;

import com.java8.Interfaces.ThreadIntferf;

public class LamdaThread1 {

	
	public static void main(String[] args) {
		
		
		
		Runnable tf = ()->{new Thread().start();};
		tf.run();
		for(int i=0;i<100;i++) {
			System.out.println("main thread::::"+i);
		}
		for(int i=0;i<100;i++) {
			System.out.println("child thread::::"+i);
		}
	}
}
