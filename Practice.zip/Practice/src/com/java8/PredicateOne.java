package com.java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PredicateOne {

	public static void main(String[] args) {

		/*Scanner sc = new Scanner(System.in);
		System.out.println("Enter Desin");
		String de = sc.next();
		
		Predicate<String> p = str->str.equalsIgnoreCase("SE");
		
		if(p.test(de))
			System.out.println("Allowed");*/

		int[] arr = new int[] {1,2,3,6,2,3};
		List<Integer> li =new ArrayList<>();;
		
		
		for(int i : arr) {
			if(!li.contains(i)){
				li.add(i);
			}
		}
		
	      int intArray[] = new int[li.toArray().length];
	      for(int i=0; i<li.toArray().length; i++){
	         intArray[i] = (int) li.toArray()[i];
	      }
		
		for(int i : intArray) {
			System.out.println(i);
		}

	}

}
