package com.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class Streams1 {
	
	public static void main(String[] args) {
		
		ArrayList<Integer> li = new ArrayList<Integer>();
		li.add(10);
		li.add(20);
		li.add(39);
		
		List<Integer> l = li.stream().map(i-> i*i).collect(Collectors.toList());
		
		System.out.println(l);
		
	}

}
