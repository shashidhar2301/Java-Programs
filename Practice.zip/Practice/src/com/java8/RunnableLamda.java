package com.java8;

public class RunnableLamda {

	public static void main(String[] args) {
		
		//Thread1 t2 = new Thread1();
		//
		Runnable t2  = ()-> {
			for(int i=0;i<100;i++) {
				System.out.println("Heloo"+i);
			}
		};
		Thread t = new Thread(t2);
		t.start();
		for(int i=0;i<100;i++) {
			System.out.println(":"+i);
		}
		
	}
	
	
}
/*class Thread1 implements Runnable{

	@Override
	public void run() {
		for(int i=0;i<100;i++) {
			System.out.println("Heloo"+i);
		}
		
	}
	
}*/
