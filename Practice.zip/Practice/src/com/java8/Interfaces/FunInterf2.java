package com.java8.Interfaces;

public interface FunInterf2 {

	int getLength(String str);
}
