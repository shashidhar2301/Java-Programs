package com.java8.Interfaces;

public interface ThreadIntferf extends Runnable{
	
	

}
