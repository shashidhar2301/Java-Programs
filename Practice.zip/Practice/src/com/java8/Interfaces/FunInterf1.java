package com.java8.Interfaces;

@FunctionalInterface
public interface FunInterf1 {

	public void add(int a, int b);
}
