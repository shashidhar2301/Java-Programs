package com.java8.Interfaces.predefined;

public class Student {

	private int id;
	private double marks;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(double marks) {
		this.marks = marks;
	}
	
	Student(int id1, double mar){
		this.id = id1;
		this.marks = mar;
	}
	public String toString() {
		return id+"::"+marks;
		
	}
	
	
	
}
