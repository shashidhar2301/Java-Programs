package com.java8.Interfaces.predefined;

import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.function.Function;

public class FunctionOne {
	
	
	public static void main(String[] args) {
		
		ArrayList<Student> li = new ArrayList();
		li.add(new Student(10,100.0));
		li.add(new Student(10,456.0));
		
		Function<Student,Student> f = s -> {
			s.setMarks(s.getMarks()*10);
			return s;
		};
		 
		
		/*for(Student s1 : li) {
			f.apply(s1);
		}*/
		Consumer<Student> c = p ->{
		f.apply(p);
		System.out.println(p);
		};
	
		for(Student s1 : li) {
			c.accept(s1);
		}
	}
	

}
