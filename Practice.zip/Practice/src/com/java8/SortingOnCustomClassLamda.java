package com.java8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class SortingOnCustomClassLamda {

	public static void main(String[] args) {
		
		Student s = new Student(10,"Shiva");
	//	System.out.println(s.toString());
		List<Student> li = new ArrayList<Student>();
		li.add(new Student(10,"Shiva"));
		li.add(new Student(20,"Manu"));
		li.add(new Student(6,"chinna"));
		//System.out.println(li);
		Collections.sort(li, (i1,i2)->(i1.id>i2.id)?-1 : (i1.id<i2.id)?1 :0  );
		//System.out.println("after sort::"+li);
		
		
		HashMap<Integer, String> hm = new HashMap<>();
		hm.put(100, "a");
		hm.put(20, "b");
		hm.put(2, "c");
		System.out.println(hm);
		Collections.emptyList();
	}
}
