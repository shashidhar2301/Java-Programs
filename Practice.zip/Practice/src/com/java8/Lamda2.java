package com.java8;

import com.java8.Interfaces.FunInterf2;

public class Lamda2 {
	public static void main(String[] args) {
		
		FunInterf2 f2 = (str)->{ return str.length();};
		int  i = f2.getLength("abce");
		System.out.println(i);
		f2.getLength("a");
	}
}
