package com.String;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class StringSSN {

	public static void main(String[] args) {
		
		String s1 = new String("Shashidhar").intern();
		String s2 = "Shashidhar".intern();
		System.out.println(s1==s2+""+s1.equals(s1));
		
		LinkedList<String> li = new LinkedList<>();
		ArrayList<String> arr = new ArrayList<>();
		li.add("a");
		li.add("b");
		li.add("c");
		for(String s : li) {
			/*if(s=="b") {
				li.remove("b");
			}*/
		//	li.remove(1);
		}
		//li.add
	//	System.out.println(li);
		
		//arr.remo
		Iterator ii = li.iterator();
		
		while(ii.hasNext()) {
		//	System.out.println(ii.next());
			if(ii.next()=="c")
			ii.remove();
		}
		System.out.println(li);
		
		/*String str = "434256";
		
		String newSTR = "";
		
		String reverseStr = "";
		
		for(int i=str.length()-1;i>=0;i--) {
			reverseStr = reverseStr + str.charAt(i);
		}
			for(int i=0;i<str.length()/2;i++) {
				int j =0;
				j =  (Integer.parseInt(str.valueOf(str.charAt(i))) + 
						(Integer.parseInt(str.valueOf(reverseStr.charAt(i))))) ;
				newSTR = newSTR + String.valueOf(j);
			}
			System.out.println(newSTR);		*/
		
		
		int i = 5;
		int[] arr = new int[] {56,456,31,898,204};
		
		
		
		/*for(int j = 0;j<arr.length;j++) {
			int num = arr[j];
			int temp = 0;
			while(num>0) {
			temp = temp + num % 10;
			num = num /10;
			}
			
			System.out.println(temp);
		}*/
		
		String str ="junnu";
		
		//Set<Character> s = new HashSet<>();
		/*for(int k=0;k<str.length();k++) {
			if(!s.add(str.charAt(k))) {
				//s.add(str.charAt(k));
				//System.out.println(s);
			}
		}*/
		char[] c = str.toCharArray(); 
		/*ArrayList<> li = Arrays.asList(c);
		Set<Character> s = new HashSet<>(li);*/
		
		
	//	List<char[]> asList = Arrays.asList(c); // because this DOES compile.

	    List<Character> listC = new ArrayList<Character>();
	    for (char ch : c) {
	        listC.add(ch);
	    }
	    System.out.println(listC);
	    Set<Character> s = new HashSet<>(listC);
	    System.out.println(s);
		/*for(char ch : c) {
			if(s.add(ch)==false) {
				//s.add(str.charAt(k));
				System.out.println(s);
			}
		}*/
	
		
		
	}
	

}
;