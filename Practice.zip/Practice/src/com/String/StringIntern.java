package com.String;

public class StringIntern {
	
	public static void main(String[] args) {
		
		// It will create object at string constant pool
		String s1 = "abcd";
		String s2 = "abcd";
		//System.out.println(s1.hashCode()+"::"+s2.hashCode());
		System.out.println(s1==s2);
		
		//It will create object at Heap Memory
		String s3 = new String("abcd");
		String s8 = new String("abcd");
		//If we call Intern method on s3, it will check whether with same any string is available at
		//String constant pool or not. If exists, it returns same address else new address will be created.
		System.out.println((s3==s8)+":"+(s1==s2)+""+s3.equals(s8)+"::"+s1.equals(s2)+"::"+s1.equals(s3));
		//false:truetrue::true::true
		System.out.println((s3==s1)+":"+s3.hashCode()+"::"+s3.equals(s1));
		String s4 = s3.intern();
		System.out.println((s1==s3)+"::"+(s1==s4));
		
		String s5 = "abcd";
		String s6 = "abcd";
		System.out.println("last:::"+(s5==s6)+"::"+(s5.equals(s6)));
		
		
		String str = "13/09/2021";
		
		String ss = str.substring(str.lastIndexOf("/")+1,str.length());
		System.out.println("ss----"+ss);
	}

}
