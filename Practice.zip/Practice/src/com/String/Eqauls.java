package com.String;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Eqauls {

	public static void main(String[] args) {

		HashMap<Integer, String> hm = new HashMap<>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Size");
		int length = sc.nextInt();
		for (int i = 0; i < length; i++) {
			hm.put(i, sc.next());
		}
		System.out.println("Hashmap values are :");
		for (Map.Entry<Integer, String> e : hm.entrySet()) {
			System.out.println("Key=" + e.getKey() + ",Element=" + e.getValue());
		}

		List<String> list = hm.values().stream().map(s -> new StringBuffer(s).reverse().toString())
				.collect(Collectors.toList());
		System.out.println("Reversed country names are :");
		for(String s : list) {
			System.out.println(s);
		}
		
		List<String> sortedList = list.stream().sorted().collect(Collectors.toList());
		System.out.println("Sorted country names are :");
		for(String s : sortedList) {
			System.out.println(s);
		}

		HashMap<Integer, String> sortedMap = new HashMap<>();
		for (int i = 0; i < sortedList.size(); i++) {
			sortedMap.put(i, sortedList.get(i));
		}
		System.out.println("Hashmap values are :");
		for (Map.Entry<Integer, String> e : sortedMap.entrySet()) {
			System.out.println("Key=" + e.getKey() + ",Element=" + e.getValue());
		}
		sc.close();
	}
}
