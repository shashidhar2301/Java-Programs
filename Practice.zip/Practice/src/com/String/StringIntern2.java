package com.String;

public class StringIntern2 {
	
	public static void main(String[] args) {
		
		String str = "Hello		 Welcome to Java!";
		String str1 = str.replaceAll("\\s","");
		System.out.println(str1);
		
		
		 char[] ch = str.toCharArray();
		 StringBuffer sb = new StringBuffer();
		 
		 
		 
		 for(int i=0;i<ch.length;i++) {
			 if(ch[i]!='\s' ) {
				 sb.append(ch[i]);
			 }
			 
		 }
		 System.out.println(sb);
		}

}
