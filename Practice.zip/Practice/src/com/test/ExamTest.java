package com.test;

import java.text.DecimalFormat;

public class ExamTest {
	
	public static void main(String[] args) throws InterruptedException{


		int i =000000001;
		DecimalFormat df=new DecimalFormat("0000");
		//String i=00001;
		//i=df.format(i);
		
		DecimalFormat decimalFormat = new DecimalFormat("000");                
	    System.out.println(decimalFormat.format(i));
	    
	    
		String s = String.valueOf(i);
		System.out.println(s+"----"+i+":::"+i%10);
		System.out.println(i/10);
	}
	


@Override
protected void finalize() {
	System.out.println("finnn");
}
}