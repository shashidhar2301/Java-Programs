package com.test;

public class Test extends Thread{
	public static void main(String[] args) {}
	
	public void run() {
		for(int i=0;i<15;i++) {
			System.out.println("child Thread");
		}
		
	}
	
		/*String str = "shashidhar";
		
		char[] ch = str.toCharArray();
		
		for(int i=ch.length-1;i>=0;i--) {
			System.out.println(ch[i]);
		}*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		
		9,3,9,3,9,7,9 ==>7
		
		9,7,3,9,7,3,7 ==> 7
		ArrayList<Integer> li = new ArrayList<>();
		li.add(9);
		li.add(7);
		li.add(3);
		li.add(9);
		li.add(7);
		li.add(3);
		li.add(7);
		
		HashMap<Integer,Integer> hm = new HashMap<Integer, Integer>();
		
		for(Integer i : li) {
		
		if(hm.containsKey(i)) {
		hm.put(i, hm.get(i)+1);
		}else
		hm.put(i,1);
		
		}
		
		for(Entry<Integer, Integer> e : hm.entrySet()) {
		if(e.getValue()%2==1) {
		System.out.println(e.getKey());
		}
		
		
		}
		
		
		Object[] obj = li.toArray();
		
		for(int i=0;i<obj.length;i++) {
		
		
		}
		
		
		*/}
//}
