package com.test;

public class ThreadTest implements Runnable{

	public static void main(String[] args) {
		
		ThreadTest test = new ThreadTest();
		Thread th = new Thread(test);
		th.start();
	}
	
	public void run() {
		System.out.println("Thread executed");
	}
}
