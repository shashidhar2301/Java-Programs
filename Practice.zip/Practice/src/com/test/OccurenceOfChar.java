
package com.test;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class OccurenceOfChar {
	public static void main(String[] args) {
		
		String str ="Hi hello! Welcome".toUpperCase();
		LinkedHashMap<Character,Integer> hm = new LinkedHashMap<>();
		/*for(int i=0;i<str.length();i++) {
			if(hm.get(str.charAt(i))==null)
				hm.put(str.charAt(i), 1);
			else
				hm.put(str.charAt(i), hm.get(str.charAt(i))+1);
			
		}*/
		char[] ch = str.toCharArray();
		for(char ch1 : ch) {
			if(ch1!=' ') {
			if(hm.get(ch1)==null)
				hm.put(ch1, 1);
			else
				hm.put(ch1, hm.get(ch1)+1);
			}
		}
		for(Entry<Character, Integer> e : hm.entrySet()) {
			System.out.println(e.getKey()+"::"+e.getValue());
			if(e.getValue()==1) {
				
				System.out.println("First non repeated char :::"+e.getKey());
				break;
			}
		}
	}
}
