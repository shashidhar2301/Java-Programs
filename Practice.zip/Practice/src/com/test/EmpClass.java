package com.test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class EmpClass {
	
	public static void main(String[] args) {
		List<EmployeeTest> li = new ArrayList<>() ;
		EmployeeTest e = new EmployeeTest();
		e.setEmpID(101);
		e.setEmpName("abcd");
		e.setEmpSal(500000);
		li.add(e);
		EmployeeTest e1 = new EmployeeTest();
		e1.setEmpID(101);
		e1.setEmpName("abcd");
		e1.setEmpSal(20000);
		li.add(e1);
		Collections.sort(li);
		for(int i=0;i<li.size();i++) {
			EmployeeTest e2= li.get(i);
			if(e2.getEmpSal()>50000) {
				System.out.println("Sr Dev");
			}else {
				
			}
			System.out.println(e2.toString());
		}
		//()->{
		
		//Collections.sort(li, Comparable<EmployeeTest>
		
	}

		 
	
	

}
