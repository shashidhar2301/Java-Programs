package com.test;

public class Instancevar {
	 int i=20;
	
	public static void main(String[] args) {
		new Instancevar().test();
		
		/*System.out.println(i);
		test();
		System.out.println(":"+i);*/
	}
	 void test(){
		i=10;
		System.out.println("i"+i);
	}

}
