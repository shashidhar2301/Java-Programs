package com.test;

public class TestNew {

	public static void main(String[] args) {
		//System.out.println(m("Hi",m("Hello",false) || m("no",true)));
		
		String strr = "nanabcdef";
		//System.out.println(strr.length());
		//strr = strr.substring(3, strr.length());
		strr = strr.substring(0, 3);
		//System.out.println(strr.length()+"::"+strr);
		//System.out.println(strr.indexOf("nan"));
		
		boolean flag = false;
		
		if(flag==false) {
			System.out.println("L:::::::"+flag);
		}

	}
	static boolean m(String str, boolean b){
		
		//b= str!=null ?  true : false;
		
		if(b)
			str = str +str;
		//System.out.println(str);
		return b;
		
	}
	
	/*Hello
	nono
	HiHi
	true
	*/

}
