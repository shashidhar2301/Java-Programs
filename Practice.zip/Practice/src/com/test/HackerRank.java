package com.test;

public class HackerRank {
	public static void main(String[] args) {
		//	B bObj =  new B();
			//bObj.method1();
			String s1 = new String("hello");
			String s2 = new String("hello");
			System.out.println(s1==s2+":"+s1.equals(s2));
			System.out.println("iujhg"+s1.equals(s2));
	}	
}

/*class A {
	A(){};
	void method1(){
		System.out.println("I am in A");
	}
}
class B extends A {
	B(){
		super();
	}
	void method1(){
		System.out.println("I am in b");
	}
}*/
