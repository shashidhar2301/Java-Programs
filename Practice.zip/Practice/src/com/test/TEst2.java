package com.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;

public class TEst2 {
	public static void main(String[] args) {
		LinkedHashMap<Integer, String> li = new LinkedHashMap<>();
		LinkedHashMap<Integer, String> newli = new LinkedHashMap<>();
		li.put(10, "ab");
		li.put(20, "nh");
		li.put(5, "nh");
		List list = new ArrayList();
		for(Entry<Integer, String> e : li.entrySet()) {
			list.add(e.getKey());
		}
		Collections.sort(list);
		for(int i=0;i<list.size();i++) {
			newli.put((Integer) list.get(i),li.get(list.get(i)));
		}
		System.out.println(newli);
		
		

	}
	
}
