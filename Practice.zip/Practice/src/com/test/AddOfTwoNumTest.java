package com.test;

import java.util.ArrayList;
import java.util.List;

public class AddOfTwoNumTest {
	
	public static void main(String[] args) {
		
		int[] data  = new int[] {4,-3,1,-1,2,-2,5,-5,8};
		//int[] newArr = new int[data.length];
		List<Integer> li = new ArrayList<>();
		//int j=0;
		for(int i=0;i<data.length;i++) {
			if((i+1)< data.length && data[i]+data[i+1]!=0 || ((i+1)== data.length)) {
				//newArr[i] = data[i];
				li.add(data[i]);
				//j++;
			}else
				i=i+1;
			
		}
		//System.out.println(li.toArray());
		Object[] newArr = li.toArray();
		for(int i=0;i<newArr.length;i++) {
			System.out.println(newArr[i]);
			
		}
		
	}



	
	

}
