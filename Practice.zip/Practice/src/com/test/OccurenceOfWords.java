package com.test;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

public class OccurenceOfWords {
	
	public static void main(String[] args) {

		String str ="hello hi this is shashidhar i am good i am indian";
		LinkedHashMap<String, Integer> hm = new LinkedHashMap<>();
		String[] s = str.split(" ");

		/*
		 * for(int i=0;i<s.length;i++){
		 * 
		 * if(hm.get(s[i])==null) hm.put(s[i],1); else hm.put(s[i],hm.get(s[i])+1);
		 * 
		 * }
		 */
		
		for(String s1 : s){
			
			if(hm.get(s1)==null)
				hm.put(s1,1);
			else
				hm.put(s1,hm.get(s1)+1);

		}
		
		Set<Entry<String, Integer>> f = hm.entrySet();
		
		Iterator i = 	f.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}

		for(Entry<String, Integer> e : hm.entrySet())
			System.out.println(e.getKey()+"::"+e.getValue());
		
			
	}

}
