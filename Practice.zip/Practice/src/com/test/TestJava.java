package com.test;

public class TestJava {
	
	
	
	public static void main(String[] args) {
		
		String s = "shashidhar";
		char[] ch = s.toCharArray();
		for(int i=ch.length-1;i>=0;i--) {
			System.out.print(ch[i]);
		}
		System.out.println("\n");
		for(int i=s.length()-1;i>=0;i--) {
			System.out.print(s.charAt(i));
		}
		
	//}

		int x= 10;
		int y= 20;
		
		/*x = x+y;//30
		y = x -y;//10
		x = x - y;
		*/
		int temp;
		
		temp =x;//10
		x= y;//20
		y = temp;//20
		System.out.println(x+"::"+y);
		
		System.out.println(x+"::"+y);
		
		//select distinct deptName from student;
		
		//select substring(name,1,3) from student;
		
		//
		
	}
}
