package com.test;

public class ThreadExample {
	
	public static void main(String[] args) {
		ThreadExample threadExample = new ThreadExample(); 
		ThreadOne threadOne = new ThreadOne(threadExample);
		threadOne.start();
		
		ThreadTwo threadTwo = new ThreadTwo(threadExample);
		threadTwo.start();
	}
	 void print(){
		for(int i=0;i<10;i++) {
			System.out.println("val : "+i);
		}
	}

}
class ThreadOne extends Thread{
	
	ThreadExample threadEx;
	ThreadOne(ThreadExample threadEx){
		this.threadEx = threadEx;
	}
	@Override
	public  void run() {
		threadEx.print();
	}
		
}
class ThreadTwo extends Thread{
	
	ThreadExample threadEx;
	ThreadTwo(ThreadExample threadEx){
		this.threadEx = threadEx;
	}
	@Override
	public void run() {
		threadEx.print();
		
	}
}
