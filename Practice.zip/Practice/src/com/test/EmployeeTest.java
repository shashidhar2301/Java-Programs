package com.test;

import java.util.Comparator;

public class EmployeeTest implements Comparable<EmployeeTest>{
	
	private int empID;
	private String empName;
	private double empSal;
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "EmployeeTest [empID=" + empID + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
	
	/*@Override
	public int compare(EmployeeTest o1, EmployeeTest o2) {
		if(o1.getEmpSal()>o2.getEmpSal())
			return 1;
		else if(o1.getEmpSal()<o2.getEmpSal())
			return -1;
		else
			return 0;
	}*/
	@Override
	public int compareTo(EmployeeTest o) {
		return (int) (this.empSal - o.empSal);
		//return 0;
	}

	
}
