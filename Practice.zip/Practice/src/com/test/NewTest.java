package com.test;

public class NewTest {

	/*Input : Hi I am Shashidhar
	Output : rahdihsahS ma I iH*/
	
	public static void main(String[] args) {
		
		String str = "Hi I am Shashidhar";
		
		for(int i=str.length()-1;i>=0;i--) {
			System.out.print(str.charAt(i));
		}
		
		/*char[] ch = str.toCharArray();
		for(int i=ch.length-;i)
		*/
		//10
		//1 2 3 5 8 13
		
		//int[] num = new int[] {1,2,3,5,8,13};
		int num =10;
		int temp=0, temp1 =1,n=0;;
		System.out.println(temp+","+temp1);
		for(int i=2;i<=num;i++) {
			n = temp +temp1;
			temp = temp1;
			temp1 = n;
			System.out.println(n);
		}
		/*n3=n1+n2;    
		  System.out.print(" "+n3);    
		  n1=n2;    
		  n2=n3;   */
		
		
	}
}
