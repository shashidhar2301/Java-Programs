package com.test;

public class Palindrome {

	public static void main(String[] args) {
		
		/*String str = "cabbac",newStr = "";
		
		String[] s1 = str.split("");
		
		for(int i=s1.length-1;i>=0;i--) {
			newStr = newStr+s1[i];
		}
		if(str.equals(newStr)) {
			System.out.println("yes");
		}else
			System.out.println("noo");*/
		
		/*int num =1, fact=1;
		
		for(int i =1;i<=num;i++) {
			
			fact = fact*i;
			
		}
		System.out.println("factorial::"+fact);*/
		
		
		/*int num=143;
		
		for(int i=1;i<=143;i++) {
			if(num%i==0) {
				System.out.println(i);
			}
		}*/
		
		int i =195, newNumber =0;
		
		while(i>0) {
			
			newNumber = (newNumber*10) + i%10;
			//newNumber = newNumber *10;//590
			i=i/10;
			
		}
		System.out.println(newNumber);
		
		
	}
	
	
}
