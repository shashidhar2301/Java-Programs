package com.polymorphism;

public class MethodOverLoading {

	static int i ;
	
	
	public static void main(String[] args) {
		i =80;
		System.out.println("main block"+i);
		 //method(10,20);
		String str = Double.toString(Math.random()*1000000+10000);
		System.out.println(str+"::"+str.substring(0,6));
		 
	}
	
	/*void method(int a, float b, int c) {
		
	};
	static void method(float a, int b) {
		
	};*/
	static {
		i=90;
		System.out.println("static block"+i);
	};
	
	void method(int a, float b) {
		
	};
	  void method1(float a, int b) {
		
	};
	
}
