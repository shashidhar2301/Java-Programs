package com.shiva.test;

public class Employee {
	private int sid;
	private String name;
	private String branch;
	
	
	public Employee() {
		super();
	}
	
	
	public int getSid() {
		return sid;
	}


	public void setSid(int sid) {
		this.sid = sid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getBranch() {
		return branch;
	}


	public void setBranch(String branch) {
		this.branch = branch;
	}


	public Employee(int sid, String name, String branch) {
		//super();
		sid = sid;
		this.name = name;
		branch = branch;
	}


	
	public static void main(String[] args) {
		First f = new GrandCHild();
		f.display();
		
	}

	/*public int add(int arr, int k) {
		 
	}
	public void add(int i, int k) {
		 
	}*/
	public void add(float arr, float k) {
		 
	}
	
	public void add(double arr, float k) {
	 double d = 10;
	 float f =90;
	 //d+f;
	 System.out.println();
	}
	
	public void change(int[] arr) {
		arr[0] =10;
		arr[1] = arr[0]+3;
	}
	 
	/*@Override
	public String toString() {
		return "Employee [sid=" + sid + ", name=" + name + ", year=" + year + "]";
	}*/
	
	
}
