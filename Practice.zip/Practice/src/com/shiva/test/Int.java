package com.shiva.test;

public interface Int {
  int cal(int a, int b);
}
