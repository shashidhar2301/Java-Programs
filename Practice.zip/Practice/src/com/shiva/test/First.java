package com.shiva.test;

import java.util.HashMap;
import java.util.Map;

public class First {
	protected int pid=0;
	protected static String pStr ="P";
	public First() {
		this.pid++;
		First.pStr+='P';
	}
	protected void display(){
		System.out.println(this.pid+"::"+First.pStr);
	}

	
	
	
}


class child extends First{
	
	protected int cid=0;
	protected static String cStr ="C";
	public child() {
		this.cid++;
		child.cStr+=this.pStr;
	}
	protected void display(){
		super.display();
		System.out.println(this.cid+"::"+child.cStr);
	}
}


class GrandCHild extends child{
	
	private int gcid;
	private static String gStr ="G";
	GrandCHild() {
		this.gcid++;
		GrandCHild.gStr+=child.cStr+First.pStr;
	}
	protected void display(){
		super.display();
		System.out.println(this.gcid+"::"+GrandCHild.gStr);
	}
}