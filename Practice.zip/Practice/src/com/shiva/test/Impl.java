package com.shiva.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

  class Impl{
	int vecId;
	String vchType;
	double price;
	public Impl(int vecId, double price) {
		this();
		this.vecId = vecId;
		this.price = price;
	}
	public Impl(String vchType) {
		this.vchType = vchType;
	}
	public Impl() {
		this.vecId = 1001;
		this.vchType = "Bike";
		this.price = 50000;
	}
	
	
	
}
