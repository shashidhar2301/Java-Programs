package om.demo;

public class Assignments{

	   int serial_No;
	   String student_Name;
	   String subject;
	   String assignmentCategory;
	   String date_of_Submission;
	   int points;

	  public Assignments(int serial_No,String student_Name,String subject,String assignmentCategory,String date_of_Submission,int points){
	     this.serial_No=serial_No;
	     this.student_Name=student_Name;
	     this.subject=subject;
	     this.assignmentCategory=assignmentCategory;
	     this.date_of_Submission=date_of_Submission;
	     this.points=points;

	   }
	    public int getSerial_No() {
	        return serial_No;
	    }
	    public String getStudent_Name() {
	        return student_Name;
	    }
	     public String getSubject() {
	        return subject;
	    }
	     public String getAssignmentCategory() {
	        return assignmentCategory;
	    }
	     public String getDate_of_Submission() {
	        return date_of_Submission;
	    }
	     public int getPoints() {
	        return points;
	    }


	}
