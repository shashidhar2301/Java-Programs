package om.demo;

import java.io.Console;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class MainClass{

	  public static void main(String[] args){
	   ArrayList<Students> studentlist= new ArrayList<Students>();

	   ArrayList<Assignments> assignmentlist= new ArrayList<Assignments>();
	   Assignments ass1=new Assignments(1, "Ananth", "Electro Fields","test_1", " 21-Jul-16", 100);
	   Assignments ass2=new Assignments(2, "Bhagath", "Electro Fields","test_1", "21-Jul-16", 78);
	   Assignments ass3=new Assignments(3, "Chaya", "Electro Fields", "test_1"," 21-Jul-16 ",68);
	   Assignments ass4=new Assignments(4, "Esharath", "Electro Fields", "test_1 ","21-Jul-16", 87);
	   Assignments ass5=new Assignments(5, "Bhagath", " Electro Fields","quiz_1", "22-Jul-16", 20);
	   Assignments ass6=new Assignments(6, "Chaya"," Electro Fields"," lab_1 ","23-Jul-16", 10);
	   Assignments ass7=new Assignments(7, "Ananth ","Electro Fields"," project_1"," 24-Jul-16", 100); 
	   Assignments ass8=new Assignments(8, "Davanth ","Electro Fields"," project_1 ","24-Jul-16", 100);
	   Assignments ass9=new Assignments(9, "Bhagath"," Electro Fields"," quiz_2","25-Jul-16", 50);
	   Assignments ass10=new Assignments(10, "Ananth", " Electro Fields","quiz_1","26-Jul-16",100);

	  assignmentlist.add(ass1);
	  assignmentlist.add(ass2);
	  assignmentlist.add(ass3);
	  assignmentlist.add(ass4);
	  assignmentlist.add(ass5);
	  assignmentlist.add(ass6);
	  assignmentlist.add(ass7);
	  assignmentlist.add(ass8);
	  assignmentlist.add(ass9);
	  assignmentlist.add(ass10);

	  ArrayList<Distribution> distributionlist= new ArrayList<Distribution>();
	    Distribution dis1 = new Distribution("Test", 40);
	    Distribution dis2 = new Distribution("Quiz", 20);
	    Distribution dis3 = new Distribution("labwork", 10);
	    Distribution dis4 = new Distribution("project", 30);

	   distributionlist.add(dis1);
	   distributionlist.add(dis2);
	   distributionlist.add(dis3);
	   distributionlist.add(dis4);

	 System.out.println("Assignments details......"+assignmentlist);
	 System.out.println("Distribution details......"+distributionlist);

	 Console console=System.console();
	 if(console==null){
	 System.out.println("No console: not in interactive mode!");
	 System.exit(0);
	 }

	System.out.println("Enter the student name....");
	String student=console.readLine();
	/*for(Assignments assignment:assignmentlist){
	if(assignment.getStudent_Name().equals(student)){

	   
	 }
	}*/

	Assignments assignment=assignmentlist.stream().
			filter(a->a.getStudent_Name().equals(student)).collect(Collectors.toList()).get(0);
	System.out.println("Students details....."+assignment);
	
	Students stu = new Students();


	}



	}