package om.demo;

import java.util.ArrayList;

public class Students{
	   ArrayList<Assignments> assObj= new ArrayList<Assignments>();
	   int testScore;
	   int quizScore;
	   int labScore;
	   int projectScore;
	   int overallRating;

	 // testScore= ((40/2)*100 +(40/2)*100)/100;

	 }