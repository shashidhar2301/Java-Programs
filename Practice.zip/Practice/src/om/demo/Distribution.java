package om.demo;

public class Distribution {
    String assignment_Category ;
    int weight;

 public Distribution(String assignment_Category , int weight){

      this.assignment_Category=assignment_Category;
      this.weight=weight;
 }
public String getAssignment_Category() {
     return assignment_Category;
 }
 public int getWeight() {
     return weight;
 }

}